#include <sys/types.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <netdb.h>
#include <stdio.h>
#include "FileUtil.h"
#include "RecieverThreads.h"
#include <pthread.h>
int tcp_recive_started =0 , resend_start=0;

void *TCP_Control(void *arg) {
	printf("Strated Control\n");
	int sockfd, newsockfd, n;
	socklen_t clilen;
	struct sockaddr_in serv_addr, cli_addr;
	char s[20];

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if (sockfd < 0)
		error("ERROR opening socket");

	bzero((char *) &serv_addr, sizeof(serv_addr));

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(port_TCPControl);
//
	if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
		error("ERROR on binding");

	listen(sockfd, 5);
	clilen = sizeof(cli_addr);

	newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);

	if (newsockfd < 0)
		error("ERROR on accept");

	n = read(newsockfd, s, 20);
	if (n < 0)
			error("ERROR reading from socket");

	NUMPACKETS = atoi(s);
	printf("Got The Number of Packetes from Sender :%d\n", NUMPACKETS);

	n = read(newsockfd, s, 20);



	if (n < 0)
		error("ERROR reading from socket");

	printf("can i start = %s\n",s);
	tcp_recive_started= 1;
	close(newsockfd);

	return NULL;
}

void *sendErrorSeq(void *arg) {
	while(tcp_recive_started==0){
		usleep(100);
	}
	while(resend_start ==0){
		usleep(100);
	}

	printf("Inside sendErrorSeq\n");
	char allones[NUMPACKETS];
	memset(allones, '1', NUMPACKETS);
	int sockfd, n;
	//int sockUDP;
	struct sockaddr_in serv_addr;
	struct hostent *server;

	sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd < 0) {
		error("ERROR opening socket");
	}
	//TODO: add struct
	server = (struct hostent *) arg;
	if (server == NULL) {
		fprintf(stderr, "ERROR, no such host\n");
		exit(0);
	}
	bzero((char *) &serv_addr, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	bcopy((char *) server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
	serv_addr.sin_port = htons(port_sendfromreceiver);
	if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) {
		error("Error connect:");
	}
	printf("Resend Packets = %s\n", PACKETS);
	printf("all ones  = %s , %d\n ", allones, strcmp(PACKETS, allones));

	while (strcmp(PACKETS, allones)!=0) {
		printf("Received sending Packets = %s\n", PACKETS);
		n = send(sockfd, PACKETS, NUMPACKETS, 0);

		if (n < 0) {
			error("ERROR writing to socket");
		}
		usleep(1000);
	}
	printf("before sending allones send Errseq\n");
	n = send(sockfd, PACKETS, NUMPACKETS, 0);
	if (n < 0) {
		error("ERROR writing to socket");
	}
	printf("after sending allones sendErrseq\n");
	printf("Packets = %s\n", PACKETS);
	close(sockfd);

	return NULL;
}

void *udp_recieve(void * argv) {
	printf("started udp reciever Pckets = %d\n", NUMPACKETS);
	PACKETS = (char*) malloc(NUMPACKETS);
	memset(PACKETS, '0', NUMPACKETS);
	char allones [NUMPACKETS+1];
	memset(allones, '1', NUMPACKETS);
	allones[NUMPACKETS] = '\0';
	int sock, length, n, i;
	FILE *fp;

	initFilePtr("y.txt", &fp, "w");

	Message *temp = (Message*) malloc(sizeof(Message));
	socklen_t fromlen;
	struct sockaddr_in server;
	struct sockaddr_in from;

	sock = socket(AF_INET, SOCK_DGRAM, 0);
	if (sock < 0) {
		error("Opening socket");
	}
	length = sizeof(server);
	bzero(&server, length);
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons(atoi((char *) (argv)));
	if (bind(sock, (struct sockaddr *) &server, length) < 0) {
		error("binding");
	}

	fromlen = sizeof(struct sockaddr_in);
	int prev =0;
	while ((i = strcmp(PACKETS, allones))!=0) {
		n = recvfrom(sock, temp, sizeof(Message), 0, (struct sockaddr *) &from,
				&fromlen);
		if (n < 0) {
			error("recvfrom");
		}
		PACKETS[temp->seq] = '1';
		if(temp->seq - prev >1){
			resend_start = 1;
		}
		printf("PACKETS = %s\n",PACKETS);
		writeChunk(fp, temp, temp->seq);
		prev = temp->seq;
	}
	free(temp);

	close(sock);
	printf("UDP Recieve end\n");
	return NULL;
}
